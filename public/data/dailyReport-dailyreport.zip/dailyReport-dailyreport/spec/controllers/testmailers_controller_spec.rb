require 'spec_helper'

describe TestmailersController do

end
