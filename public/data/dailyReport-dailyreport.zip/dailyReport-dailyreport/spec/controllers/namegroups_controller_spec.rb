require 'spec_helper'

describe NamegroupsController do

end
