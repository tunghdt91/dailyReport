require 'spec_helper'

describe GroupsController do

end
