require 'spec_helper'

describe ActivesController do

end
