require 'spec_helper'

describe CatalogsController do

end
