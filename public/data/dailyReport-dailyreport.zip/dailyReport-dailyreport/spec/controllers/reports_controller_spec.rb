require 'spec_helper'

describe ReportsController do

end
