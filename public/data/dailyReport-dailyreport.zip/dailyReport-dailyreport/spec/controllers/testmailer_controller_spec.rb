require 'spec_helper'

describe TestmailerController do

end
