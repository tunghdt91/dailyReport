# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
DailyReport::Application.config.secret_token = '3c13e1be0b83be1f10d91123eddc4eeca2fac08003e7ff9822bbe51ae52c2a8b92af6fa12bb31aceafe0b80d3b2acc5258d4a5d1818c83a9d49e5902ca17d800'
