class Namegroup < ActiveRecord::Base
  attr_accessible :group_id, :group_name
end
