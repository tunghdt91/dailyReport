module NamegroupsHelper
end
