require 'spec_helper'

describe ProductsController do

end
