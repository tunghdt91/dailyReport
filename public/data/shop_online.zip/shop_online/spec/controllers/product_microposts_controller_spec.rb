require 'spec_helper'

describe ProductMicropostsController do

end
