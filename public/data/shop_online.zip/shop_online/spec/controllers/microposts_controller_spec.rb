require 'spec_helper'

describe MicropostsController do

end
