require 'spec_helper'

describe SessionsController do

end
