require 'spec_helper'

describe CartsController do

end
