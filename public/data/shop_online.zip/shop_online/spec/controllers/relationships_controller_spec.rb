require 'spec_helper'

describe RelationshipsController do

end
