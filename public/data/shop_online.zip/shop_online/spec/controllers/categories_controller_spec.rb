require 'spec_helper'

describe CategoriesController do

end
