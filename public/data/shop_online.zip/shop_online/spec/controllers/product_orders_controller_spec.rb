require 'spec_helper'

describe ProductOrdersController do

end
