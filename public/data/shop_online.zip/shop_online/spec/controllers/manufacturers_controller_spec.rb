require 'spec_helper'

describe ManufacturersController do

end
