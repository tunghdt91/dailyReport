require 'spec_helper'

describe Micropost do
  pending "add some examples to (or delete) #{__FILE__}"
end
