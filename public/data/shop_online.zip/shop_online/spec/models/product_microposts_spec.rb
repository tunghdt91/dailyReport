require 'spec_helper'

describe ProductMicroposts do
  pending "add some examples to (or delete) #{__FILE__}"
end
