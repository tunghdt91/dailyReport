# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
ShopOnline::Application.config.secret_token = '38e75544986e41c6e4fd6faa8d5048b4c30e88d064674093668caafe0c539295fcbe8f9535b83a7e2427e3776af76fd9bba835bedef17f500fd95ba0a51bdc49'
